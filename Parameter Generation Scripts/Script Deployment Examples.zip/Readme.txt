In order to test the Parameter Generatation Scripts, please follow the instructions of each script.

Best Regards,
Sharif Mobile Computing Group
	
