Run the 'SavePycaffeModelInMessagePack.py' to test the prepared script for Caffe.
Open Terminal and run the following commands:
	- cd ~/Desktop/CNNdroid/Parameter\ Generation\ Scripts/Caffe/
	- python SavePycaffeModelInMessagePack.py	
Converted Parameters will be available in the Generated Parameters directory.
