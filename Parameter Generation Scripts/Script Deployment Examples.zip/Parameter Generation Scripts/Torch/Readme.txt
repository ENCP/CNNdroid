Open Terminal and run the following commands:
	- cd ~/Desktop/CNNdroid/Parameter\ Generation\ Scripts/Torch/
	- th SaveTorchModelinMessagepack.lua
Converted Parameters will be available in the Generated Parameters directory.
