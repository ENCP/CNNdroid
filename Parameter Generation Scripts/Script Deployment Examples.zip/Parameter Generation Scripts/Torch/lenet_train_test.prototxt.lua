require 'nn'
local model = {}
-- warning: module 'mnist [type Data]' not found
table.insert(model, {'conv1', nn.SpatialConvolution(1, 20, 5, 5, 1, 1, 0, 0)})
table.insert(model, {'pool1', nn.SpatialMaxPooling(2, 2, 2, 2, 0, 0):ceil()})
table.insert(model, {'conv2', nn.SpatialConvolution(20, 50, 5, 5, 1, 1, 0, 0)})
table.insert(model, {'pool2', nn.SpatialMaxPooling(2, 2, 2, 2, 0, 0):ceil()})
table.insert(model, {'torch_view', nn.View(-1):setNumInputDims(3)})
table.insert(model, {'ip1', nn.Linear(800, 500)})
table.insert(model, {'relu1', nn.ReLU(true)})
table.insert(model, {'ip2', nn.Linear(500, 10)})
return model