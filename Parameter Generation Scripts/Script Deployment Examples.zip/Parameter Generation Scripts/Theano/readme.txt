Run the 'TestTheanoScript.py' to test the prepared script for Theano.
Open Terminal and run the following commands:
	- cd ~/Desktop/CNNdroid/Parameter\ Generation\ Scripts/Theano/
	- python TestTheanoScript.py	
Converted Parameters will be available in the Generated Parameters directory.
