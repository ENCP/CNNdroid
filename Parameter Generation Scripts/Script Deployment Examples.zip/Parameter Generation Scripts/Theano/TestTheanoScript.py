#These functions have been generated to save the trained model
#parameters of Theano in Messagepack which will be accesible through
#AndroidConvNet library

#List of functions:
#   1- save_numpy_parameters
#   2- save_tensor_parameters


import numpy as np
import msgpack as mp


# Saving path:
SAVE_TO = '/home/cnndroid/Desktop/CNNdroid/Parameter Generation Scripts/Theano/Generated Parameters/'


#Function to save parameters num numpy array format
#if weight_parameter is weight of a convolution layer:
#   Dimensions: (next layer features, previous layer features, kernel height, kernel width)
def save_numpy_parameters(weight_parameter, bias_parameter, layer_name):
    weight = weight_parameter.astype('float32')
    bias = bias_parameter.astype('float32')
    if len(weight.shape) is 4:
        buf1 = mp.packb(weight.tolist())
    else:
        buf1 = mp.packb(weight.flatten().tolist())
    buf2 = mp.packb(bias.tolist())
    with open(SAVE_TO + 'model_param_'+ layer_name + '.msg', 'wb') as f:
        f.write(buf1)
        f.write(buf2)    
    print('Saved data:')
    print(layer_name + '.weight & ' + layer_name + ".bias in 'model_param_" + layer_name + ".msg'")



def save_tensor_parameters(weight_parameter, bias_parameter, layer_name):
    np_weight = np.asanyarray(weight_parameterb.eval())
    np_bias = np.asanyarray(bias_parameterb.eval())
    save_numpy_parameters(np_weight, np_bias, layer_name)


#Conversion of Conv1 and FC6 layers of AlexNet. 
Conv1_w = np.random.randn(96,3,11,11)
Conv1_b = np.random.randn(96)
FC6_w = np.random.randn(1000,4096)
FC6_b = np.random.randn(1000)

save_numpy_parameters(Conv1_w, Conv1_b,'conv1')
save_numpy_parameters(FC6_w, FC6_b,'fc8')
# They also could be in Theano Tensor format.
        
        
